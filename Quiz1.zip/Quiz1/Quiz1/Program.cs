﻿using System;

namespace Quiz1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome to AM's Gas Station");
            Console.WriteLine("----------------------------");
            Console.WriteLine("Regular  Midgrade  Premium");
            Console.WriteLine(" $4.39    $4.59     $4.69");
            Console.WriteLine("Your Type of Gas (R/M/P): ");
            char type = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("How many gallons?: ");
            double gallons = Convert.ToInt32(Console.ReadLine());

            if (type == 'R')
            {
                double regular = 4.39;
                double total1;
                total1 = regular * gallons;

                Console.WriteLine("Car Wash Today (Y/N): ");
                char carWash = Convert.ToChar(Console.ReadLine());
                if (carWash == 'Y')
                {
                    double wash = 4.5;
                    double total4;
                    total4 = wash + total1;
                    Console.WriteLine("Your total is: $" + total4 + " for " + gallons + " gallons of regular gas and a car wash.");
                }
                else
                {
                    Console.WriteLine("Your regular gas total is: $" + total1 + " for " + gallons + " gallons of regular gas.");
                }
            }
            else if (type == 'M')
            {
                double midgrade = 4.59;
                double total2;
                total2 = midgrade * gallons;

                Console.WriteLine("Car Wash Today (Y/N): ");
                char carWash = Convert.ToChar(Console.ReadLine());
                if (carWash == 'Y')
                {
                    double wash = 4.5;
                    double total5;
                    total5 = wash + total2;
                    Console.WriteLine("Your total is: $" + total5 + " for " + gallons + " gallons of midgrade gas and a car wash.");
                }
                else
                {
                    Console.WriteLine("Your regular gas total is: $" + total2 + " for " + gallons + " gallons of midgrade gas.");
                }
            }
            else
            {
                double premium = 4.69;
                double total3;
                total3 = premium * gallons;

                Console.WriteLine("Car Wash Today (Y/N): ");
                char carWash = Convert.ToChar(Console.ReadLine());
                if (carWash == 'Y')
                {
                    double wash = 4.5;
                    double total6;
                    total6 = wash + total3;
                    Console.WriteLine("Your total is: $" + total6 + " for " + gallons + " gallons of premium gas and a car wash.");
                }
                else
                {
                    Console.WriteLine("Your regular gas total is: $" + total3 + " for " + gallons + " gallons of premium gas.");
                }
            }
        }
    }
}